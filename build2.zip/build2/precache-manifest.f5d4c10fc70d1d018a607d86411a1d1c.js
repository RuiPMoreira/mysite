self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "49965267a9734c486ba456b69451248c",
    "url": "/index.html"
  },
  {
    "revision": "09bf90bb971e08666331",
    "url": "/static/css/main.94e3fbf8.chunk.css"
  },
  {
    "revision": "cb270e364e6dafda9496",
    "url": "/static/js/2.76a88f64.chunk.js"
  },
  {
    "revision": "d705cb622423d72c5defbf368ca70dcc",
    "url": "/static/js/2.76a88f64.chunk.js.LICENSE"
  },
  {
    "revision": "09bf90bb971e08666331",
    "url": "/static/js/main.fb8e761a.chunk.js"
  },
  {
    "revision": "9aedf1ef7999bbd8dbd5",
    "url": "/static/js/runtime-main.01ad01f3.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);